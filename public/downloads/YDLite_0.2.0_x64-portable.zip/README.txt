YDLite 0.2.0 portable
=====================

Run YDLite.exe directly. No installation is needed.

Download tools
--------------
yt-dlp and FFmpeg are looked up next to the executable:

  YDLite.exe
  tools\yt-dlp.exe
  tools\ffmpeg\ffmpeg.exe
  tools\ffmpeg\ffprobe.exe

If those files are missing, the app falls back to whatever is on PATH.
To install them into the portable folder, open Settings and use
"Install missing tools" (Internet required).

Your data
---------
Settings, history and download preferences are stored in the WebView2
profile of this Windows user, not next to the executable. Copying the
.exe to another machine gives you a clean configuration.

Requirements
------------
Windows 10/11 x64 with the Microsoft Edge WebView2 runtime
(preinstalled on current Windows 10 and 11).
